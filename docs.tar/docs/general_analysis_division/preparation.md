---
id: preparation
title: "利用の準備"
---

公開鍵を登録してください。
